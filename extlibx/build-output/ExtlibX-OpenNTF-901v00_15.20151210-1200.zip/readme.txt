XPagesExtLibX
=============

OPENNTF
=======
This project is an OpenNTF project, and is available under the Apache Licence V2.0. All other aspects of the project, including contributions, defect reports, discussions, feature requests and reviews are subject to the OpenNTF Terms of Use - available at [http://openntf.org/Internal/home.nsf/dx/Terms_of_Use](http://openntf.org/Internal/home.nsf/dx/Terms_of_Use).

The source code of the project is available under the Apache License V2.0 at: https://github.com/OpenNTF/XPagesExtLibX 

Bootstrap 4 Alpha
=================
Bootstrap 4 is the next major release of the open-source Bootstrap project. The first release was over 4 years ago, and each major release has brought with it significant changes. Currently, Bootstrap 4 is in alpha state, with a yet to be announced full release date. We are adding the alpha version of Bootstrap 4 to the ExtLibX project now in order to start preparing for Bootstrap 4’s future release. By laying the foundation for Boostrap 4 in XPages in the ExtLibX project during the alpha phase, it will facilitate its addition to the core Extension Library in a prompt manner once Bootstrap 4 is actually released. Futhermore, it gives the XPages community the opportunity to contribute to the development of Bootstrap 4 support in XPages between now and its official release.